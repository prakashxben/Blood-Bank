package com.lifestream.repository;

import com.lifestream.model.BloodRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BloodRequestRepository extends JpaRepository<BloodRequest, Long> {
    List<BloodRequest> findByStatusOrderByRequestDateDesc(String status);
    List<BloodRequest> findByBloodGroupOrderByRequestDateDesc(String bloodGroup);
    List<BloodRequest> findByUrgencyOrderByRequestDateDesc(String urgency);
}