CREATE TABLE IF NOT EXISTS blood_inventory (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    blood_group VARCHAR(10) UNIQUE NOT NULL,
    available_units INT NOT NULL,
    donors_count INT NOT NULL
);