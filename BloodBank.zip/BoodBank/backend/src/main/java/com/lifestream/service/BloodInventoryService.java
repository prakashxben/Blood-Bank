package com.lifestream.service;

import com.lifestream.model.BloodInventory;
import com.lifestream.repository.BloodInventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class BloodInventoryService {
    
    @Autowired
    private BloodInventoryRepository bloodInventoryRepository;
    
    public List<BloodInventory> getAllInventory() {
        return bloodInventoryRepository.findAll();
    }
    
    public Optional<BloodInventory> getInventoryByBloodGroup(String bloodGroup) {
        return bloodInventoryRepository.findByBloodGroup(bloodGroup);
    }
    
    public BloodInventory updateInventory(String bloodGroup, Integer unitsChange) {
        Optional<BloodInventory> inventoryOpt = bloodInventoryRepository.findByBloodGroup(bloodGroup);
        if (inventoryOpt.isPresent()) {
            BloodInventory inventory = inventoryOpt.get();
            int newUnits = Math.max(0, inventory.getAvailableUnits() + unitsChange);
            inventory.setAvailableUnits(newUnits);
            return bloodInventoryRepository.save(inventory);
        }
        return null;
    }
    
    public BloodInventory saveInventory(BloodInventory inventory) {
        return bloodInventoryRepository.save(inventory);
    }
}