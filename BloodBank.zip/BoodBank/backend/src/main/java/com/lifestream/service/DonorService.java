package com.lifestream.service;

import com.lifestream.model.Donor;
import com.lifestream.repository.DonorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class DonorService {
    
    @Autowired
    private DonorRepository donorRepository;
    
    public List<Donor> getAllDonors() {
        return donorRepository.findAll();
    }
    
    public Optional<Donor> getDonorById(Long id) {
        return donorRepository.findById(id);
    }
    
    public Donor registerDonor(Donor donor) {
        if (donorRepository.existsByEmail(donor.getEmail())) {
            throw new RuntimeException("Donor with this email already exists");
        }
        return donorRepository.save(donor);
    }
    
    public List<Donor> getDonorsByBloodGroup(String bloodGroup) {
        return donorRepository.findByBloodGroup(bloodGroup);
    }
    
    public List<Donor> getAvailableDonors() {
        return donorRepository.findByIsAvailableTrue();
    }
    
    public Donor updateDonorAvailability(Long id, Boolean isAvailable) {
        Optional<Donor> donorOpt = donorRepository.findById(id);
        if (donorOpt.isPresent()) {
            Donor donor = donorOpt.get();
            donor.setIsAvailable(isAvailable);
            return donorRepository.save(donor);
        }
        return null;
    }
    
    public void deleteDonor(Long id) {
        donorRepository.deleteById(id);
    }
}