package com.lifestream.controller;

import com.lifestream.dto.ApiResponse;
import com.lifestream.model.BloodRequest;
import com.lifestream.service.BloodRequestService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/requests")
@CrossOrigin(origins = "*")
public class BloodRequestController {
    
    @Autowired
    private BloodRequestService bloodRequestService;
    
    @GetMapping
    public ApiResponse getAllRequests() {
        try {
            List<BloodRequest> requests = bloodRequestService.getAllRequests();
            return ApiResponse.success("Blood requests retrieved successfully", requests);
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving blood requests: " + e.getMessage());
        }
    }
    
    @PostMapping
    public ApiResponse createBloodRequest(@Valid @RequestBody BloodRequest bloodRequest) {
        try {
            BloodRequest savedRequest = bloodRequestService.createRequest(bloodRequest);
            return ApiResponse.success("Blood request submitted successfully", savedRequest);
        } catch (Exception e) {
            return ApiResponse.error("Error submitting blood request: " + e.getMessage());
        }
    }
    
    @GetMapping("/status/{status}")
    public ApiResponse getRequestsByStatus(@PathVariable String status) {
        try {
            List<BloodRequest> requests = bloodRequestService.getRequestsByStatus(status);
            return ApiResponse.success("Blood requests retrieved successfully", requests);
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving blood requests: " + e.getMessage());
        }
    }
    
    @GetMapping("/blood-group/{bloodGroup}")
    public ApiResponse getRequestsByBloodGroup(@PathVariable String bloodGroup) {
        try {
            List<BloodRequest> requests = bloodRequestService.getRequestsByBloodGroup(bloodGroup);
            return ApiResponse.success("Blood requests retrieved successfully", requests);
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving blood requests: " + e.getMessage());
        }
    }
    
    @PutMapping("/{id}/status")
    public ApiResponse updateRequestStatus(@PathVariable Long id, @RequestParam String status) {
        try {
            BloodRequest request = bloodRequestService.updateRequestStatus(id, status);
            if (request != null) {
                return ApiResponse.success("Request status updated successfully", request);
            } else {
                return ApiResponse.error("Request not found with id: " + id);
            }
        } catch (Exception e) {
            return ApiResponse.error("Error updating request status: " + e.getMessage());
        }
    }
    
    @DeleteMapping("/{id}")
    public ApiResponse deleteRequest(@PathVariable Long id) {
        try {
            bloodRequestService.deleteRequest(id);
            return ApiResponse.success("Blood request deleted successfully");
        } catch (Exception e) {
            return ApiResponse.error("Error deleting blood request: " + e.getMessage());
        }
    }
}