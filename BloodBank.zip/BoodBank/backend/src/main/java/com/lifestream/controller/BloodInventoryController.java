package com.lifestream.controller;

import com.lifestream.dto.ApiResponse;
import com.lifestream.model.BloodInventory;
import com.lifestream.service.BloodInventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/inventory")
@CrossOrigin(origins = "*")
public class BloodInventoryController {
    
    @Autowired
    private BloodInventoryService bloodInventoryService;
    
    @GetMapping
    public ApiResponse getAllInventory() {
        try {
            List<BloodInventory> inventory = bloodInventoryService.getAllInventory();
            return ApiResponse.success("Inventory retrieved successfully", inventory);
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving inventory: " + e.getMessage());
        }
    }
    
    @GetMapping("/{bloodGroup}")
    public ApiResponse getInventoryByBloodGroup(@PathVariable String bloodGroup) {
        try {
            BloodInventory inventory = bloodInventoryService.getInventoryByBloodGroup(bloodGroup)
                    .orElse(null);
            if (inventory != null) {
                return ApiResponse.success("Inventory retrieved successfully", inventory);
            } else {
                return ApiResponse.error("Inventory not found for blood group: " + bloodGroup);
            }
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving inventory: " + e.getMessage());
        }
    }
}