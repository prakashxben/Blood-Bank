package com.lifestream.service;

import com.lifestream.model.BloodRequest;
import com.lifestream.repository.BloodRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class BloodRequestService {
    
    @Autowired
    private BloodRequestRepository bloodRequestRepository;
    
    public List<BloodRequest> getAllRequests() {
        return bloodRequestRepository.findAll();
    }
    
    public Optional<BloodRequest> getRequestById(Long id) {
        return bloodRequestRepository.findById(id);
    }
    
    public BloodRequest createRequest(BloodRequest bloodRequest) {
        return bloodRequestRepository.save(bloodRequest);
    }
    
    public List<BloodRequest> getRequestsByStatus(String status) {
        return bloodRequestRepository.findByStatusOrderByRequestDateDesc(status);
    }
    
    public List<BloodRequest> getRequestsByBloodGroup(String bloodGroup) {
        return bloodRequestRepository.findByBloodGroupOrderByRequestDateDesc(bloodGroup);
    }
    
    public BloodRequest updateRequestStatus(Long id, String status) {
        Optional<BloodRequest> requestOpt = bloodRequestRepository.findById(id);
        if (requestOpt.isPresent()) {
            BloodRequest request = requestOpt.get();
            request.setStatus(status);
            return bloodRequestRepository.save(request);
        }
        return null;
    }
    
    public void deleteRequest(Long id) {
        bloodRequestRepository.deleteById(id);
    }
}