package com.lifestream.model;

import jakarta.persistence.*;

@Entity
@Table(name = "blood_inventory")
public class BloodInventory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "blood_group", unique = true, nullable = false)
    private String bloodGroup;
    
    @Column(name = "available_units", nullable = false)
    private Integer availableUnits;
    
    @Column(name = "donors_count", nullable = false)
    private Integer donorsCount;
    
    // Constructors
    public BloodInventory() {}
    
    public BloodInventory(String bloodGroup, Integer availableUnits, Integer donorsCount) {
        this.bloodGroup = bloodGroup;
        this.availableUnits = availableUnits;
        this.donorsCount = donorsCount;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }
    
    public Integer getAvailableUnits() { return availableUnits; }
    public void setAvailableUnits(Integer availableUnits) { this.availableUnits = availableUnits; }
    
    public Integer getDonorsCount() { return donorsCount; }
    public void setDonorsCount(Integer donorsCount) { this.donorsCount = donorsCount; }
}