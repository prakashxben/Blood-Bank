INSERT INTO blood_inventory (blood_group, available_units, donors_count) VALUES 
('A+', 42, 12),
('A-', 18, 7),
('B+', 35, 15),
('B-', 12, 5),
('O+', 55, 22),
('O-', 25, 9),
('AB+', 8, 3),
('AB-', 5, 2);