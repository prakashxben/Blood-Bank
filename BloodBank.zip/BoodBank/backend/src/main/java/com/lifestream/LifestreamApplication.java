package com.lifestream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifestreamApplication {

    public static void main(String[] args) {
        SpringApplication.run(LifestreamApplication.class, args);
        System.out.println("=========================================");
        System.out.println("LifeStream Blood Bank Backend Started!");
        System.out.println("Server: http://localhost:8080");
        System.out.println("H2 Database: http://localhost:8080/h2-console");
        System.out.println("=========================================");
    }
}