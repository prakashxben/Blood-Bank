package com.lifestream.config;

import com.lifestream.model.BloodInventory;
import com.lifestream.repository.BloodInventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private BloodInventoryRepository bloodInventoryRepository;

    @Override
    public void run(String... args) throws Exception {
        // Only load if database is empty
        if (bloodInventoryRepository.count() == 0) {
            bloodInventoryRepository.save(new BloodInventory("A+", 42, 12));
            bloodInventoryRepository.save(new BloodInventory("A-", 18, 7));
            bloodInventoryRepository.save(new BloodInventory("B+", 35, 15));
            bloodInventoryRepository.save(new BloodInventory("B-", 12, 5));
            bloodInventoryRepository.save(new BloodInventory("O+", 55, 22));
            bloodInventoryRepository.save(new BloodInventory("O-", 25, 9));
            bloodInventoryRepository.save(new BloodInventory("AB+", 8, 3));
            bloodInventoryRepository.save(new BloodInventory("AB-", 5, 2));
            
            System.out.println("✅ Initial blood inventory loaded!");
        }
    }
}
