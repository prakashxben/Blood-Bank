package com.lifestream.controller;

import com.lifestream.dto.ApiResponse;
import com.lifestream.model.Donor;
import com.lifestream.service.DonorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/donors")
@CrossOrigin(origins = "*")
public class DonorController {
    
    @Autowired
    private DonorService donorService;
    
    @GetMapping
    public ApiResponse getAllDonors() {
        try {
            List<Donor> donors = donorService.getAllDonors();
            return ApiResponse.success("Donors retrieved successfully", donors);
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving donors: " + e.getMessage());
        }
    }
    
    @PostMapping("/register")
    public ApiResponse registerDonor(@Valid @RequestBody Donor donor) {
        try {
            Donor savedDonor = donorService.registerDonor(donor);
            return ApiResponse.success("Donor registered successfully", savedDonor);
        } catch (Exception e) {
            return ApiResponse.error("Error registering donor: " + e.getMessage());
        }
    }
    
    @GetMapping("/blood-group/{bloodGroup}")
    public ApiResponse getDonorsByBloodGroup(@PathVariable String bloodGroup) {
        try {
            List<Donor> donors = donorService.getDonorsByBloodGroup(bloodGroup);
            return ApiResponse.success("Donors retrieved successfully", donors);
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving donors: " + e.getMessage());
        }
    }
    
    @GetMapping("/available")
    public ApiResponse getAvailableDonors() {
        try {
            List<Donor> donors = donorService.getAvailableDonors();
            return ApiResponse.success("Available donors retrieved successfully", donors);
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving available donors: " + e.getMessage());
        }
    }
    
    @PutMapping("/{id}/availability")
    public ApiResponse updateDonorAvailability(@PathVariable Long id, @RequestParam Boolean available) {
        try {
            Donor donor = donorService.updateDonorAvailability(id, available);
            if (donor != null) {
                return ApiResponse.success("Donor availability updated successfully", donor);
            } else {
                return ApiResponse.error("Donor not found with id: " + id);
            }
        } catch (Exception e) {
            return ApiResponse.error("Error updating donor availability: " + e.getMessage());
        }
    }
    
    @DeleteMapping("/{id}")
    public ApiResponse deleteDonor(@PathVariable Long id) {
        try {
            donorService.deleteDonor(id);
            return ApiResponse.success("Donor deleted successfully");
        } catch (Exception e) {
            return ApiResponse.error("Error deleting donor: " + e.getMessage());
        }
    }
}